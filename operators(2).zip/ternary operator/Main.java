import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("ternary operator");
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter age: ");
        int age = sc.nextInt();   

        String result = (age > 18) ? "Eligible" : "Not Eligible";

        System.out.println(result);
    }
}
