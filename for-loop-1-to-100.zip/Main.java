

public class Main {
    public static void main(String[] args) {
        System.out.println("FOR LOOP 1 TO 100");
        
       
       for( int i=1;i<100;i++){
           System.out.println(i);
       }
    }
}