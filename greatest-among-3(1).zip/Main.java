import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("GREATEST AMONG 3 NUMBERS");

        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a: ");
        int a = sc.nextInt();

        System.out.print("Enter b: ");
        int b = sc.nextInt();

        System.out.print("Enter c: ");
        int c = sc.nextInt();

        if (a > b && a > c) {
            System.out.println("a is the greatest number");
        } 
        else if (b > a && b > c) {
            System.out.println("b is the greatest number");
        } 
        else {
            System.out.println("c is the greatest number");
        }
    }
}
